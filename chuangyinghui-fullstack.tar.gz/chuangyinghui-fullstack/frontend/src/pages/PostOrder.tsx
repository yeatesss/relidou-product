import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { ArrowLeft, CheckCircle, Upload, Info } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'

const videoTypes = [
  '产品展示视频',
  '品牌宣传视频',
  'UGC真人出镜',
  '短视频广告',
  '电商主图视频',
  '动画/MG视频',
  '直播切片',
  '口播视频',
  '3D产品渲染',
]

const budgetRanges = [
  '¥500以下',
  '¥500-1000',
  '¥1000-2000',
  '¥2000-5000',
  '¥5000-10000',
  '¥10000以上',
]

const durations = [
  '1-3天',
  '3-7天',
  '7-15天',
  '15-30天',
  '1个月以上',
]

export default function PostOrder() {
  const navigate = useNavigate()
  const [isVisible, setIsVisible] = useState(false)
  const [step, setStep] = useState(1)
  const [formData, setFormData] = useState({
    title: '',
    type: '',
    budget: '',
    duration: '',
    description: '',
    requirements: '',
    location: '全国',
    files: [] as File[],
  })

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const handleSubmit = () => {
    alert('订单发布成功！')
    navigate('/orders')
  }

  const isStep1Valid = formData.title && formData.type && formData.budget && formData.duration
  const isStep2Valid = formData.description && formData.description.length >= 50

  return (
    <div className="min-h-screen bg-[#f7f7f7] pt-20">
      {/* Header */}
      <div className="bg-white border-b border-[#e4e5e7]">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 text-[#74767e] hover:text-[#1dbf73] transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            返回
          </button>
        </div>
      </div>

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Title */}
        <div className={`text-center mb-8 transition-all duration-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
          <h1 className="text-3xl font-bold text-[#404145] mb-2">发布视频订单</h1>
          <p className="text-[#74767e]">描述您的需求，让创作者主动找上门</p>
        </div>

        {/* Progress */}
        <div className={`flex items-center justify-center gap-4 mb-8 transition-all duration-500 delay-100 ${isVisible ? 'opacity-100' : 'opacity-0'}`}>
          <div className={`flex items-center gap-2 ${step >= 1 ? 'text-[#1dbf73]' : 'text-[#74767e]'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-[#1dbf73] text-white' : 'bg-[#e4e5e7]'}`}>
              1
            </div>
            <span className="hidden sm:inline">基本信息</span>
          </div>
          <div className="w-12 h-0.5 bg-[#e4e5e7]">
            <div className={`h-full bg-[#1dbf73] transition-all ${step >= 2 ? 'w-full' : 'w-0'}`} />
          </div>
          <div className={`flex items-center gap-2 ${step >= 2 ? 'text-[#1dbf73]' : 'text-[#74767e]'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-[#1dbf73] text-white' : 'bg-[#e4e5e7]'}`}>
              2
            </div>
            <span className="hidden sm:inline">需求详情</span>
          </div>
          <div className="w-12 h-0.5 bg-[#e4e5e7]">
            <div className={`h-full bg-[#1dbf73] transition-all ${step >= 3 ? 'w-full' : 'w-0'}`} />
          </div>
          <div className={`flex items-center gap-2 ${step >= 3 ? 'text-[#1dbf73]' : 'text-[#74767e]'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 3 ? 'bg-[#1dbf73] text-white' : 'bg-[#e4e5e7]'}`}>
              3
            </div>
            <span className="hidden sm:inline">确认发布</span>
          </div>
        </div>

        {/* Form */}
        <div className={`bg-white rounded-xl p-6 md:p-8 shadow-sm transition-all duration-500 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
          {step === 1 && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-[#404145] mb-2">
                  订单标题 <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="例如：美妆品牌抖音短视频拍摄"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full p-3 border border-[#e4e5e7] rounded-lg focus:outline-none focus:border-[#1dbf73] focus:ring-2 focus:ring-[#1dbf73]/20"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#404145] mb-2">
                  视频类型 <span className="text-red-500">*</span>
                </label>
                <div className="flex flex-wrap gap-2">
                  {videoTypes.map((type) => (
                    <button
                      key={type}
                      onClick={() => setFormData({ ...formData, type })}
                      className={`px-4 py-2 rounded-lg border transition-all ${
                        formData.type === type
                          ? 'bg-[#1dbf73] text-white border-[#1dbf73]'
                          : 'border-[#e4e5e7] text-[#404145] hover:border-[#1dbf73]'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#404145] mb-2">
                  预算范围 <span className="text-red-500">*</span>
                </label>
                <div className="flex flex-wrap gap-2">
                  {budgetRanges.map((budget) => (
                    <button
                      key={budget}
                      onClick={() => setFormData({ ...formData, budget })}
                      className={`px-4 py-2 rounded-lg border transition-all ${
                        formData.budget === budget
                          ? 'bg-[#1dbf73] text-white border-[#1dbf73]'
                          : 'border-[#e4e5e7] text-[#404145] hover:border-[#1dbf73]'
                      }`}
                    >
                      {budget}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#404145] mb-2">
                  交付周期 <span className="text-red-500">*</span>
                </label>
                <div className="flex flex-wrap gap-2">
                  {durations.map((duration) => (
                    <button
                      key={duration}
                      onClick={() => setFormData({ ...formData, duration })}
                      className={`px-4 py-2 rounded-lg border transition-all ${
                        formData.duration === duration
                          ? 'bg-[#1dbf73] text-white border-[#1dbf73]'
                          : 'border-[#e4e5e7] text-[#404145] hover:border-[#1dbf73]'
                      }`}
                    >
                      {duration}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#404145] mb-2">
                  工作地点
                </label>
                <select
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  className="w-full p-3 border border-[#e4e5e7] rounded-lg focus:outline-none focus:border-[#1dbf73]"
                >
                  <option value="全国">全国</option>
                  <option value="北京">北京</option>
                  <option value="上海">上海</option>
                  <option value="广州">广州</option>
                  <option value="深圳">深圳</option>
                  <option value="杭州">杭州</option>
                  <option value="成都">成都</option>
                </select>
              </div>

              <div className="flex justify-end">
                <Button
                  onClick={() => setStep(2)}
                  disabled={!isStep1Valid}
                  className="bg-[#1dbf73] hover:bg-[#19a463] text-white px-8 disabled:opacity-50"
                >
                  下一步
                </Button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-[#404145] mb-2">
                  需求描述 <span className="text-red-500">*</span>
                </label>
                <textarea
                  placeholder="详细描述您的视频需求，包括：
- 视频用途和平台
- 风格要求
- 参考案例
- 其他特殊要求"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={8}
                  className="w-full p-3 border border-[#e4e5e7] rounded-lg focus:outline-none focus:border-[#1dbf73] focus:ring-2 focus:ring-[#1dbf73]/20 resize-none"
                />
                <div className="text-right text-sm text-[#74767e] mt-1">
                  {formData.description.length}/500 字
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#404145] mb-2">
                  创作者要求
                </label>
                <textarea
                  placeholder="例如：
- 有美妆产品拍摄经验
- 熟悉抖音平台风格
- 有良好的镜头表现力"
                  value={formData.requirements}
                  onChange={(e) => setFormData({ ...formData, requirements: e.target.value })}
                  rows={4}
                  className="w-full p-3 border border-[#e4e5e7] rounded-lg focus:outline-none focus:border-[#1dbf73] focus:ring-2 focus:ring-[#1dbf73]/20 resize-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#404145] mb-2">
                  附件资料
                </label>
                <div className="border-2 border-dashed border-[#e4e5e7] rounded-lg p-8 text-center hover:border-[#1dbf73] transition-colors cursor-pointer">
                  <Upload className="w-10 h-10 text-[#74767e] mx-auto mb-3" />
                  <p className="text-[#404145] mb-1">点击或拖拽上传文件</p>
                  <p className="text-sm text-[#74767e]">支持图片、视频、文档等格式</p>
                </div>
              </div>

              <div className="flex justify-between">
                <Button
                  variant="outline"
                  onClick={() => setStep(1)}
                  className="border-[#e4e5e7]"
                >
                  上一步
                </Button>
                <Button
                  onClick={() => setStep(3)}
                  disabled={!isStep2Valid}
                  className="bg-[#1dbf73] hover:bg-[#19a463] text-white px-8 disabled:opacity-50"
                >
                  下一步
                </Button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-[#1dbf73]/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-8 h-8 text-[#1dbf73]" />
                </div>
                <h2 className="text-xl font-semibold text-[#404145] mb-2">确认订单信息</h2>
                <p className="text-[#74767e]">请核对以下信息，确认无误后发布</p>
              </div>

              <div className="bg-[#f7f7f7] rounded-lg p-6 space-y-4">
                <div className="flex justify-between">
                  <span className="text-[#74767e]">订单标题</span>
                  <span className="text-[#404145] font-medium">{formData.title}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#74767e]">视频类型</span>
                  <Badge className="bg-[#1dbf73] text-white">{formData.type}</Badge>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#74767e]">预算范围</span>
                  <span className="text-[#1dbf73] font-medium">{formData.budget}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#74767e]">交付周期</span>
                  <span className="text-[#404145] font-medium">{formData.duration}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#74767e]">工作地点</span>
                  <span className="text-[#404145] font-medium">{formData.location}</span>
                </div>
                <div className="pt-4 border-t border-[#e4e5e7]">
                  <span className="text-[#74767e] block mb-2">需求描述</span>
                  <p className="text-[#404145] text-sm whitespace-pre-line">{formData.description}</p>
                </div>
              </div>

              <div className="bg-blue-50 rounded-lg p-4 flex items-start gap-3">
                <Info className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" />
                <div className="text-sm text-blue-700">
                  <p className="font-medium mb-1">发布须知</p>
                  <p>订单发布后，创作者可以查看并投标。您可以对比多个方案后选择最合适的创作者合作。</p>
                </div>
              </div>

              <div className="flex justify-between">
                <Button
                  variant="outline"
                  onClick={() => setStep(2)}
                  className="border-[#e4e5e7]"
                >
                  上一步
                </Button>
                <Button
                  onClick={handleSubmit}
                  className="bg-[#1dbf73] hover:bg-[#19a463] text-white px-8"
                >
                  确认发布
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
