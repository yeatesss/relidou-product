import { useEffect, useState } from 'react'
import Hero from '../sections/Hero'
import Categories from '../sections/Categories'
import LatestOrders from '../sections/LatestOrders'
import TopCreators from '../sections/TopCreators'
import HowItWorks from '../sections/HowItWorks'
import TrustBadges from '../sections/TrustBadges'
import Testimonials from '../sections/Testimonials'
import CTASection from '../sections/CTASection'

export default function Home() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  return (
    <div className={isVisible ? 'opacity-100' : 'opacity-0'}>
      <Hero />
      <Categories />
      <LatestOrders />
      <TopCreators />
      <HowItWorks />
      <TrustBadges />
      <Testimonials />
      <CTASection />
    </div>
  )
}
