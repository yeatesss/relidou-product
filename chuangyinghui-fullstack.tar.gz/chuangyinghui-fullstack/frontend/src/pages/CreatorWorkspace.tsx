import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  LayoutDashboard,
  ShoppingCart,
  TrendingUp,
  MessageSquare,
  Wallet,
  Video,
  Search,
  Eye,
  CheckCircle,
  Clock,
  DollarSign,
  ChevronRight,
  Star,
  Upload,
  Plus,
  TrendingUp as TrendIcon,
  Award,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

const stats = [
  { title: '我的订单', value: '28', icon: ShoppingCart, color: 'bg-blue-500' },
  { title: '进行中', value: '5', icon: Clock, color: 'bg-yellow-500' },
  { title: '已完成', value: '23', icon: CheckCircle, color: 'bg-green-500' },
  { title: '总收入', value: '¥98,400', icon: DollarSign, color: 'bg-[#1dbf73]' },
]

const myOrders = [
  { id: 'ORD-2026-001', title: '美妆品牌抖音短视频', client: '花漾美妆', price: '¥1,200', status: '进行中', deadline: '2026-02-26', progress: 60 },
  { id: 'ORD-2026-005', title: '直播切片制作', client: '电竞俱乐部', price: '¥800', status: '待交付', deadline: '2026-02-21', progress: 90 },
  { id: 'ORD-2026-003', title: '企业宣传片剪辑', client: '互联科技', price: '¥5,000', status: '已完成', deadline: '2026-02-25', progress: 100 },
  { id: 'ORD-2026-008', title: '口播视频制作', client: '学而教育', price: '¥1,200', status: '待确认收款', deadline: '2026-02-18', progress: 100 },
]

const myBids = [
  { id: 1, order: '美妆品牌抖音短视频拍摄', client: '花漾美妆', budget: '¥800-1500', myPrice: '¥1,200', submittedAt: '2天前', status: '已中标', bids: 12 },
  { id: 2, order: '产品展示视频拍摄', client: '优品家居', budget: '¥1,500-3,000', myPrice: '¥2,500', submittedAt: '3天前', status: '待结果', bids: 8 },
  { id: 3, order: '餐饮品牌宣传片', client: '味道餐厅', budget: '¥2,000-5,000', myPrice: '¥3,800', submittedAt: '5天前', status: '未中标', bids: 15 },
  { id: 4, order: 'APP功能演示动画', client: '智慧生活', budget: '¥5,000-10,000', myPrice: '¥8,000', submittedAt: '1周前', status: '待结果', bids: 6 },
]

const myWorks = [
  { id: 1, title: '美妆品牌抖音视频', views: '12.5万', likes: 856, type: '短视频', createdAt: '2026-02-20' },
  { id: 2, title: '科技企业宣传片', views: '8.3万', likes: 623, type: '宣传片', createdAt: '2026-02-15' },
  { id: 3, title: '产品开箱测评', views: '5.6万', likes: 412, type: '测评', createdAt: '2026-02-10' },
  { id: 4, title: '旅行Vlog剪辑', views: '3.2万', likes: 298, type: 'Vlog', createdAt: '2026-02-05' },
]

const messages = [
  { id: 1, from: '花漾美妆', content: '视频效果很好，就是结尾可以再优化一下', time: '30分钟前', unread: true },
  { id: 2, from: '互联科技', content: '已确认收货，合作愉快！', time: '2小时前', unread: false },
]

const incomeData = [
  { month: '1月', amount: 8200 },
  { month: '2月', amount: 12400 },
  { month: '3月', amount: 9800 },
  { month: '4月', amount: 15600 },
  { month: '5月', amount: 18900 },
  { month: '6月', amount: 21500 },
]

const getStatusColor = (status: string) => {
  switch (status) {
    case '进行中':
    case '待结果':
      return 'bg-blue-100 text-blue-700'
    case '待交付':
    case '待确认收款':
      return 'bg-yellow-100 text-yellow-700'
    case '已完成':
    case '已中标':
      return 'bg-green-100 text-green-700'
    case '未中标':
      return 'bg-slate-100 text-slate-700'
    default:
      return 'bg-slate-100 text-slate-700'
  }
}

export default function CreatorWorkspace() {
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState('overview')
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  return (
    <div className="min-h-screen bg-[#f7f7f7] pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className={`flex items-center justify-between mb-8 transition-all duration-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
          <div>
            <h1 className="text-2xl font-bold text-[#404145]">创作者工作台</h1>
            <p className="text-[#74767e] mt-1">管理您的订单、作品和收入</p>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={() => navigate('/orders')}
              className="bg-[#1dbf73] hover:bg-[#19a463] text-white"
            >
              <Search className="w-4 h-4 mr-2" />
              找订单
            </Button>
            <Button
              variant="outline"
              onClick={() => setActiveTab('works')}
              className="border-[#e4e5e7]"
            >
              <Upload className="w-4 h-4 mr-2" />
              上传作品
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className={`grid grid-cols-2 md:grid-cols-4 gap-4 mb-8 transition-all duration-500 delay-100 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
          {stats.map((stat) => {
            const Icon = stat.icon
            return (
              <div key={stat.title} className="bg-white rounded-xl p-5 shadow-sm border border-slate-100">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[#74767e] text-sm">{stat.title}</p>
                    <p className="text-2xl font-bold text-[#404145] mt-1">{stat.value}</p>
                  </div>
                  <div className={`w-12 h-12 ${stat.color} rounded-xl flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        {/* Main Content */}
        <div className={`transition-all duration-500 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="bg-white mb-6 p-1 rounded-xl flex-wrap">
              <TabsTrigger value="overview" className="rounded-lg data-[state=active]:bg-[#1dbf73] data-[state=active]:text-white">
                <LayoutDashboard className="w-4 h-4 mr-2" />
                概览
              </TabsTrigger>
              <TabsTrigger value="orders" className="rounded-lg data-[state=active]:bg-[#1dbf73] data-[state=active]:text-white">
                <ShoppingCart className="w-4 h-4 mr-2" />
                我的订单
              </TabsTrigger>
              <TabsTrigger value="bids" className="rounded-lg data-[state=active]:bg-[#1dbf73] data-[state=active]:text-white">
                <TrendingUp className="w-4 h-4 mr-2" />
                我的投标
              </TabsTrigger>
              <TabsTrigger value="works" className="rounded-lg data-[state=active]:bg-[#1dbf73] data-[state=active]:text-white">
                <Video className="w-4 h-4 mr-2" />
                作品集
              </TabsTrigger>
              <TabsTrigger value="messages" className="rounded-lg data-[state=active]:bg-[#1dbf73] data-[state=active]:text-white">
                <MessageSquare className="w-4 h-4 mr-2" />
                消息
              </TabsTrigger>
              <TabsTrigger value="income" className="rounded-lg data-[state=active]:bg-[#1dbf73] data-[state=active]:text-white">
                <Wallet className="w-4 h-4 mr-2" />
                收入
              </TabsTrigger>
            </TabsList>

            {/* Overview */}
            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Active Orders */}
                <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                  <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                    <h3 className="font-semibold text-[#404145]">进行中的订单</h3>
                    <button onClick={() => setActiveTab('orders')} className="text-[#1dbf73] text-sm hover:underline flex items-center">
                      查看全部 <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="divide-y divide-slate-100">
                    {myOrders.filter(o => o.status === '进行中' || o.status === '待交付').map((order) => (
                      <div key={order.id} className="p-4 hover:bg-slate-50">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium text-[#404145]">{order.title}</p>
                            <p className="text-sm text-[#74767e] mt-1">甲方：{order.client}</p>
                          </div>
                          <div className="text-right">
                            <p className="text-[#1dbf73] font-medium">{order.price}</p>
                            <p className="text-xs text-[#74767e]">截止：{order.deadline}</p>
                          </div>
                        </div>
                        <div className="mt-3">
                          <div className="flex items-center justify-between text-sm mb-1">
                            <span className="text-[#74767e]">进度</span>
                            <span className="text-[#1dbf73]">{order.progress}%</span>
                          </div>
                          <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                            <div className="h-full bg-[#1dbf73] rounded-full" style={{ width: `${order.progress}%` }} />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Right Column */}
                <div className="space-y-6">
                  {/* Income Summary */}
                  <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-100">
                    <h3 className="font-semibold text-[#404145] mb-4">本月收入</h3>
                    <p className="text-3xl font-bold text-[#1dbf73]">¥12,400</p>
                    <div className="flex items-center gap-2 mt-2">
                      <TrendIcon className="w-4 h-4 text-green-500" />
                      <span className="text-sm text-green-600">+15% 较上月</span>
                    </div>
                    <div className="mt-4 pt-4 border-t border-slate-100 space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-[#74767e]">待结算</span>
                        <span className="font-medium text-[#404145]">¥3,200</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-[#74767e]">可提现</span>
                        <span className="font-medium text-[#1dbf73]">¥9,200</span>
                      </div>
                    </div>
                    <Button className="w-full mt-4 bg-[#1dbf73] hover:bg-[#19a463]">
                      申请提现
                    </Button>
                  </div>

                  {/* New Messages */}
                  <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                    <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                      <h3 className="font-semibold text-[#404145]">新消息</h3>
                      <button onClick={() => setActiveTab('messages')} className="text-[#1dbf73] text-sm hover:underline">
                        查看全部
                      </button>
                    </div>
                    <div className="divide-y divide-slate-100">
                      {messages.filter(m => m.unread).map((msg) => (
                        <div key={msg.id} className="p-4 hover:bg-slate-50 bg-blue-50/30">
                          <div className="flex items-center justify-between">
                            <p className="font-medium text-[#404145]">{msg.from}</p>
                            <span className="w-2 h-2 bg-red-500 rounded-full" />
                          </div>
                          <p className="text-sm text-[#74767e] truncate mt-1">{msg.content}</p>
                          <p className="text-xs text-[#74767e] mt-1">{msg.time}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Quick Actions */}
                  <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-100">
                    <h3 className="font-semibold text-[#404145] mb-4">快捷操作</h3>
                    <div className="grid grid-cols-2 gap-3">
                      <button onClick={() => navigate('/orders')} className="p-3 bg-[#1dbf73]/10 rounded-xl text-center hover:bg-[#1dbf73]/20 transition-colors">
                        <Search className="w-5 h-5 text-[#1dbf73] mx-auto mb-1" />
                        <p className="text-xs font-medium text-[#404145]">找订单</p>
                      </button>
                      <button onClick={() => setActiveTab('works')} className="p-3 bg-purple-50 rounded-xl text-center hover:bg-purple-100 transition-colors">
                        <Upload className="w-5 h-5 text-purple-500 mx-auto mb-1" />
                        <p className="text-xs font-medium text-[#404145]">传作品</p>
                      </button>
                      <button onClick={() => setActiveTab('bids')} className="p-3 bg-blue-50 rounded-xl text-center hover:bg-blue-100 transition-colors">
                        <TrendingUp className="w-5 h-5 text-blue-500 mx-auto mb-1" />
                        <p className="text-xs font-medium text-[#404145]">看投标</p>
                      </button>
                      <button onClick={() => setActiveTab('income')} className="p-3 bg-green-50 rounded-xl text-center hover:bg-green-100 transition-colors">
                        <Wallet className="w-5 h-5 text-green-500 mx-auto mb-1" />
                        <p className="text-xs font-medium text-[#404145]">查收入</p>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Orders */}
            <TabsContent value="orders">
              <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="p-5 border-b border-slate-100">
                  <div className="flex items-center gap-4">
                    <input
                      type="text"
                      placeholder="搜索订单..."
                      className="flex-1 max-w-md px-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-[#1dbf73]"
                    />
                    <select className="px-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-[#1dbf73]">
                      <option>全部状态</option>
                      <option>进行中</option>
                      <option>待交付</option>
                      <option>待确认收款</option>
                      <option>已完成</option>
                    </select>
                  </div>
                </div>
                <div className="divide-y divide-slate-100">
                  {myOrders.map((order) => (
                    <div key={order.id} className="p-5 hover:bg-slate-50">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium text-[#404145]">{order.title}</p>
                          <p className="text-sm text-[#74767e] mt-1">甲方：{order.client} · {order.id}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-[#1dbf73] font-medium text-lg">{order.price}</p>
                          <Badge className={getStatusColor(order.status)}>{order.status}</Badge>
                        </div>
                      </div>
                      {order.status === '进行中' && (
                        <div className="mt-4">
                          <div className="flex items-center justify-between text-sm mb-1">
                            <span className="text-[#74767e]">项目进度</span>
                            <span className="text-[#1dbf73]">{order.progress}%</span>
                          </div>
                          <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                            <div className="h-full bg-[#1dbf73] rounded-full" style={{ width: `${order.progress}%` }} />
                          </div>
                          <div className="flex gap-2 mt-3">
                            <Button size="sm" className="bg-[#1dbf73] hover:bg-[#19a463]">
                              更新进度
                            </Button>
                            <Button size="sm" variant="outline" className="border-slate-200">
                              提交交付
                            </Button>
                          </div>
                        </div>
                      )}
                      {order.status === '待确认收款' && (
                        <div className="mt-4 flex gap-2">
                          <Button size="sm" className="bg-[#1dbf73] hover:bg-[#19a463]">
                            确认收款
                          </Button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            {/* Bids */}
            <TabsContent value="bids">
              <div className="space-y-4">
                {myBids.map((bid) => (
                  <div key={bid.id} className="bg-white rounded-xl p-5 shadow-sm border border-slate-100">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-semibold text-[#404145]">{bid.order}</h4>
                        <p className="text-sm text-[#74767e] mt-1">甲方：{bid.client}</p>
                        <div className="flex items-center gap-4 mt-2 text-sm">
                          <span className="text-[#74767e]">预算：<span className="line-through">{bid.budget}</span></span>
                          <span className="text-[#1dbf73] font-medium">我的报价：{bid.myPrice}</span>
                          <span className="text-[#74767e]">共{bid.bids}人投标</span>
                        </div>
                        <p className="text-sm text-[#74767e] mt-2">投标时间：{bid.submittedAt}</p>
                      </div>
                      <div className="text-right">
                        <Badge className={getStatusColor(bid.status)}>{bid.status}</Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            {/* Works */}
            <TabsContent value="works">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-[#404145]">我的作品 ({myWorks.length})</h3>
                  <Button className="bg-[#1dbf73] hover:bg-[#19a463]">
                    <Upload className="w-4 h-4 mr-2" />
                    上传新作品
                  </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  {myWorks.map((work) => (
                    <div key={work.id} className="bg-white rounded-xl overflow-hidden shadow-sm border border-slate-100 hover:shadow-md transition-shadow">
                      <div className="aspect-video bg-gradient-to-br from-[#003912] to-[#0a4226] flex items-center justify-center">
                        <Video className="w-12 h-12 text-white/50" />
                      </div>
                      <div className="p-4">
                        <h4 className="font-medium text-[#404145] truncate">{work.title}</h4>
                        <div className="flex items-center gap-3 mt-2 text-sm text-[#74767e]">
                          <span className="flex items-center gap-1">
                            <Eye className="w-4 h-4" />
                            {work.views}
                          </span>
                          <span className="flex items-center gap-1">
                            <Star className="w-4 h-4" />
                            {work.likes}
                          </span>
                        </div>
                        <div className="flex items-center justify-between mt-3">
                          <Badge variant="secondary" className="bg-slate-100 text-slate-600">
                            {work.type}
                          </Badge>
                          <span className="text-xs text-[#74767e]">{work.createdAt}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                  {/* Add New Work Card */}
                  <button className="aspect-[4/3] bg-slate-50 rounded-xl border-2 border-dashed border-slate-200 flex flex-col items-center justify-center text-slate-400 hover:border-[#1dbf73] hover:text-[#1dbf73] transition-colors">
                    <Plus className="w-10 h-10 mb-2" />
                    <span className="text-sm">上传新作品</span>
                  </button>
                </div>
              </div>
            </TabsContent>

            {/* Messages */}
            <TabsContent value="messages">
              <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="divide-y divide-slate-100">
                  {messages.map((msg) => (
                    <div key={msg.id} className={`p-4 hover:bg-slate-50 cursor-pointer ${msg.unread ? 'bg-blue-50/30' : ''}`}>
                      <div className="flex items-start gap-4">
                        <Avatar className="w-12 h-12 bg-[#1dbf73]">
                          <AvatarFallback className="text-white">{msg.from[0]}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <p className="font-medium text-[#404145]">{msg.from}</p>
                            <span className="text-sm text-[#74767e]">{msg.time}</span>
                          </div>
                          <p className="text-sm text-[#74767e] mt-1">{msg.content}</p>
                        </div>
                        {msg.unread && <span className="w-2 h-2 bg-red-500 rounded-full" />}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            {/* Income */}
            <TabsContent value="income">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2 space-y-6">
                  {/* Income Chart Placeholder */}
                  <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-100">
                    <h3 className="font-semibold text-[#404145] mb-4">近6个月收入趋势</h3>
                    <div className="h-64 bg-slate-50 rounded-xl flex items-end justify-center gap-4 p-4">
                      {incomeData.map((data, index) => (
                        <div key={index} className="flex flex-col items-center">
                          <div
                            className="w-12 bg-[#1dbf73] rounded-t-lg transition-all hover:bg-[#19a463]"
                            style={{ height: `${(data.amount / 25000) * 200}px` }}
                          />
                          <span className="text-xs text-[#74767e] mt-2">{data.month}</span>
                          <span className="text-xs text-[#1dbf73]">¥{data.amount}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Recent Income */}
                  <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                    <div className="p-5 border-b border-slate-100">
                      <h3 className="font-semibold text-[#404145]">最近收入</h3>
                    </div>
                    <table className="w-full">
                      <thead className="bg-slate-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">订单</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">甲方</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">金额</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">日期</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">状态</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        <tr className="hover:bg-slate-50">
                          <td className="px-6 py-4 text-sm text-[#404145]">企业宣传片剪辑</td>
                          <td className="px-6 py-4 text-sm text-slate-600">互联科技</td>
                          <td className="px-6 py-4 text-[#1dbf73] font-medium">+¥5,000</td>
                          <td className="px-6 py-4 text-sm text-slate-500">2026-02-20</td>
                          <td className="px-6 py-4">
                            <Badge className="bg-green-100 text-green-700">已结算</Badge>
                          </td>
                        </tr>
                        <tr className="hover:bg-slate-50">
                          <td className="px-6 py-4 text-sm text-[#404145]">美妆短视频拍摄</td>
                          <td className="px-6 py-4 text-sm text-slate-600">花漾美妆</td>
                          <td className="px-6 py-4 text-[#1dbf73] font-medium">+¥1,200</td>
                          <td className="px-6 py-4 text-sm text-slate-500">2026-02-18</td>
                          <td className="px-6 py-4">
                            <Badge className="bg-green-100 text-green-700">已结算</Badge>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Right Sidebar */}
                <div className="space-y-4">
                  <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-100">
                    <p className="text-[#74767e] text-sm">账户余额</p>
                    <p className="text-3xl font-bold text-[#1dbf73] mt-2">¥9,200</p>
                    <div className="space-y-2 mt-4">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-[#74767e]">待结算</span>
                        <span className="font-medium text-[#404145]">¥3,200</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-[#74767e]">本月收入</span>
                        <span className="font-medium text-[#1dbf73]">¥12,400</span>
                      </div>
                    </div>
                    <Button className="w-full mt-4 bg-[#1dbf73] hover:bg-[#19a463]">
                      申请提现
                    </Button>
                  </div>

                  <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-100">
                    <h4 className="font-semibold text-[#404145] mb-3">创作者等级</h4>
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-gradient-to-br from-amber-400 to-amber-600 rounded-xl flex items-center justify-center">
                        <Award className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <p className="font-medium text-[#404145]">金牌创作者</p>
                        <p className="text-sm text-[#74767e]">已完成 23 单</p>
                      </div>
                    </div>
                    <div className="mt-3">
                      <div className="flex items-center justify-between text-sm mb-1">
                        <span className="text-[#74767e]">距离铂金还需</span>
                        <span className="text-[#1dbf73]">7单</span>
                      </div>
                      <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full bg-amber-500 rounded-full" style={{ width: '77%' }} />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
