import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Eye, EyeOff, Mail, Lock } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function Login() {
  const navigate = useNavigate()
  const [isVisible, setIsVisible] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    remember: false,
  })

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    alert('登录成功！')
    navigate('/')
  }

  return (
    <div className="min-h-screen bg-[#f7f7f7] pt-20 flex items-center justify-center py-12 px-4">
      <div className={`w-full max-w-md transition-all duration-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-[#1dbf73] rounded-xl flex items-center justify-center mx-auto mb-4">
            <span className="text-white font-bold text-2xl">创</span>
          </div>
          <h1 className="text-2xl font-bold text-[#404145]">欢迎回来</h1>
          <p className="text-[#74767e] mt-1">登录您的创影汇账号</p>
        </div>

        {/* Form */}
        <div className="bg-white rounded-xl p-8 shadow-sm">
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-[#404145] mb-2">
                邮箱/手机号
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#74767e]" />
                <input
                  type="text"
                  placeholder="请输入邮箱或手机号"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full pl-10 pr-4 py-3 border border-[#e4e5e7] rounded-lg focus:outline-none focus:border-[#1dbf73] focus:ring-2 focus:ring-[#1dbf73]/20"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-[#404145] mb-2">
                密码
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#74767e]" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="请输入密码"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full pl-10 pr-12 py-3 border border-[#e4e5e7] rounded-lg focus:outline-none focus:border-[#1dbf73] focus:ring-2 focus:ring-[#1dbf73]/20"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#74767e] hover:text-[#404145]"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.remember}
                  onChange={(e) => setFormData({ ...formData, remember: e.target.checked })}
                  className="w-4 h-4 rounded border-[#e4e5e7] text-[#1dbf73] focus:ring-[#1dbf73]"
                />
                <span className="text-sm text-[#74767e]">记住我</span>
              </label>
              <a href="#" className="text-sm text-[#1dbf73] hover:underline">
                忘记密码？
              </a>
            </div>

            <Button
              type="submit"
              className="w-full bg-[#1dbf73] hover:bg-[#19a463] text-white py-3"
            >
              登录
            </Button>
          </form>

          {/* Divider */}
          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-[#e4e5e7]" />
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-[#74767e]">或使用以下方式登录</span>
            </div>
          </div>

          {/* Social Login */}
          <div className="grid grid-cols-3 gap-3">
            <button className="flex items-center justify-center py-2.5 border border-[#e4e5e7] rounded-lg hover:bg-[#f7f7f7] transition-colors">
              <span className="text-sm">微信</span>
            </button>
            <button className="flex items-center justify-center py-2.5 border border-[#e4e5e7] rounded-lg hover:bg-[#f7f7f7] transition-colors">
              <span className="text-sm">QQ</span>
            </button>
            <button className="flex items-center justify-center py-2.5 border border-[#e4e5e7] rounded-lg hover:bg-[#f7f7f7] transition-colors">
              <span className="text-sm">微博</span>
            </button>
          </div>
        </div>

        {/* Register Link */}
        <p className="text-center mt-6 text-[#74767e]">
          还没有账号？{' '}
          <button
            onClick={() => navigate('/register')}
            className="text-[#1dbf73] font-medium hover:underline"
          >
            立即注册
          </button>
        </p>
      </div>
    </div>
  )
}
