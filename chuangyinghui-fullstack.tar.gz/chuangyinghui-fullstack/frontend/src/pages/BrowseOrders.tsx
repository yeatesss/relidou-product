import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Search, Filter, ChevronDown, Clock, Users, Banknote, MapPin, Star } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'

const categories = ['全部', '短视频', '宣传片', 'UGC', '动画', '产品展示', '口播', '直播切片', '3D渲染']
const budgets = ['全部', '¥500以下', '¥500-1000', '¥1000-2000', '¥2000-5000', '¥5000以上']
const durations = ['全部', '1-3天', '3-7天', '7-15天', '15天以上']

const orders = [
  {
    id: 1,
    title: '美妆品牌抖音短视频拍摄',
    budget: '¥800-1500',
    budgetMin: 800,
    budgetMax: 1500,
    duration: '3天',
    bids: 12,
    tags: ['短视频', '美妆'],
    postedAt: '2小时前',
    location: '全国',
    description: '需要拍摄3条15-30秒的抖音短视频，展示产品使用效果，要求真人出镜，风格年轻化。',
    client: {
      name: '花漾美妆',
      rating: 4.8,
      orders: 23,
    },
  },
  {
    id: 2,
    title: '电子产品开箱测评视频',
    budget: '¥1000-2000',
    budgetMin: 1000,
    budgetMax: 2000,
    duration: '5天',
    bids: 8,
    tags: ['测评', '3C数码'],
    postedAt: '4小时前',
    location: '全国',
    description: '新款智能手表开箱测评，需要详细展示产品功能和实际使用体验，时长3-5分钟。',
    client: {
      name: '数码科技',
      rating: 4.9,
      orders: 45,
    },
  },
  {
    id: 3,
    title: '餐饮品牌宣传片剪辑',
    budget: '¥2000-5000',
    budgetMin: 2000,
    budgetMax: 5000,
    duration: '7天',
    bids: 15,
    tags: ['宣传片', '餐饮'],
    postedAt: '6小时前',
    location: '北京',
    description: '已有拍摄素材，需要专业剪辑师进行后期制作，包括调色、配音、字幕等。',
    client: {
      name: '味道餐厅',
      rating: 4.7,
      orders: 12,
    },
  },
  {
    id: 4,
    title: '服装品牌UGC真人出镜',
    budget: '¥500-1000',
    budgetMin: 500,
    budgetMax: 1000,
    duration: '2天',
    bids: 20,
    tags: ['UGC', '服装'],
    postedAt: '8小时前',
    location: '全国',
    description: '寻找时尚博主拍摄穿搭分享视频，要求身材匀称，有镜头感。',
    client: {
      name: '潮流服饰',
      rating: 4.6,
      orders: 18,
    },
  },
  {
    id: 5,
    title: 'APP功能演示动画视频',
    budget: '¥3000-8000',
    budgetMin: 3000,
    budgetMax: 8000,
    duration: '10天',
    bids: 6,
    tags: ['MG动画', 'APP'],
    postedAt: '12小时前',
    location: '全国',
    description: '需要制作APP功能介绍动画视频，风格简洁现代，时长1-2分钟。',
    client: {
      name: '互联科技',
      rating: 5.0,
      orders: 67,
    },
  },
  {
    id: 6,
    title: '家居产品360度展示视频',
    budget: '¥1500-3000',
    budgetMin: 1500,
    budgetMax: 3000,
    duration: '5天',
    bids: 9,
    tags: ['产品展示', '家居'],
    postedAt: '1天前',
    location: '上海',
    description: '拍摄家具产品360度展示视频，用于电商平台，需要专业灯光和设备。',
    client: {
      name: '优品家居',
      rating: 4.8,
      orders: 34,
    },
  },
  {
    id: 7,
    title: '教育课程口播视频',
    budget: '¥800-1500',
    budgetMin: 800,
    budgetMax: 1500,
    duration: '3天',
    bids: 14,
    tags: ['口播', '教育'],
    postedAt: '1天前',
    location: '全国',
    description: '需要形象良好的讲师拍摄课程介绍视频，要求普通话标准，表达清晰。',
    client: {
      name: '学而教育',
      rating: 4.9,
      orders: 89,
    },
  },
  {
    id: 8,
    title: '游戏直播精彩片段剪辑',
    budget: '¥600-1200',
    budgetMin: 600,
    budgetMax: 1200,
    duration: '2天',
    bids: 11,
    tags: ['直播切片', '游戏'],
    postedAt: '2天前',
    location: '全国',
    description: '将直播录像剪辑成精彩片段合集，需要添加特效和字幕。',
    client: {
      name: '电竞俱乐部',
      rating: 4.7,
      orders: 56,
    },
  },
  {
    id: 9,
    title: '珠宝产品3D渲染视频',
    budget: '¥4000-10000',
    budgetMin: 4000,
    budgetMax: 10000,
    duration: '15天',
    bids: 4,
    tags: ['3D渲染', '珠宝'],
    postedAt: '2天前',
    location: '深圳',
    description: '需要高品质3D渲染视频展示珠宝产品细节，要求效果逼真，光影精美。',
    client: {
      name: '璀璨珠宝',
      rating: 5.0,
      orders: 15,
    },
  },
]

export default function BrowseOrders() {
  const navigate = useNavigate()
  const [selectedCategory, setSelectedCategory] = useState('全部')
  const [selectedBudget, setSelectedBudget] = useState('全部')
  const [selectedDuration, setSelectedDuration] = useState('全部')
  const [searchQuery, setSearchQuery] = useState('')
  const [showFilters, setShowFilters] = useState(false)
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const filteredOrders = orders.filter((order) => {
    if (selectedCategory !== '全部' && !order.tags.includes(selectedCategory)) return false
    if (searchQuery && !order.title.toLowerCase().includes(searchQuery.toLowerCase())) return false
    return true
  })

  return (
    <div className="min-h-screen bg-[#f7f7f7] pt-20">
      {/* Header */}
      <div className="bg-white border-b border-[#e4e5e7]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <h1 className={`text-3xl font-bold text-[#404145] mb-4 transition-all duration-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
            浏览订单
          </h1>
          <p className={`text-[#74767e] transition-all duration-500 delay-100 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
            发现优质视频需求，找到适合您的项目
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Search and Filter Bar */}
        <div className={`bg-white rounded-xl p-4 mb-6 shadow-sm transition-all duration-500 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
          <div className="flex flex-col lg:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#74767e]" />
              <input
                type="text"
                placeholder="搜索订单..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-[#e4e5e7] rounded-lg focus:outline-none focus:border-[#1dbf73] focus:ring-2 focus:ring-[#1dbf73]/20"
              />
            </div>

            {/* Filter Button */}
            <Button
              variant="outline"
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2 border-[#e4e5e7]"
            >
              <Filter className="w-4 h-4" />
              筛选
              <ChevronDown className={`w-4 h-4 transition-transform ${showFilters ? 'rotate-180' : ''}`} />
            </Button>
          </div>

          {/* Filters */}
          {showFilters && (
            <div className="mt-4 pt-4 border-t border-[#e4e5e7] grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#404145] mb-2">视频类型</label>
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="w-full p-2.5 border border-[#e4e5e7] rounded-lg focus:outline-none focus:border-[#1dbf73]"
                >
                  {categories.map((cat) => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#404145] mb-2">预算范围</label>
                <select
                  value={selectedBudget}
                  onChange={(e) => setSelectedBudget(e.target.value)}
                  className="w-full p-2.5 border border-[#e4e5e7] rounded-lg focus:outline-none focus:border-[#1dbf73]"
                >
                  {budgets.map((b) => (
                    <option key={b} value={b}>{b}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-[#404145] mb-2">交付周期</label>
                <select
                  value={selectedDuration}
                  onChange={(e) => setSelectedDuration(e.target.value)}
                  className="w-full p-2.5 border border-[#e4e5e7] rounded-lg focus:outline-none focus:border-[#1dbf73]"
                >
                  {durations.map((d) => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>
            </div>
          )}
        </div>

        {/* Results Count */}
        <div className={`mb-4 transition-all duration-500 delay-300 ${isVisible ? 'opacity-100' : 'opacity-0'}`}>
          <span className="text-[#74767e]">共找到 </span>
          <span className="font-semibold text-[#404145]">{filteredOrders.length}</span>
          <span className="text-[#74767e]"> 个订单</span>
        </div>

        {/* Orders Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredOrders.map((order, index) => (
            <div
              key={order.id}
              onClick={() => navigate(`/orders/${order.id}`)}
              className={`bg-white rounded-xl p-6 shadow-sm hover:shadow-lg hover:-translate-y-1 transition-all duration-300 cursor-pointer border border-transparent hover:border-[#1dbf73]/20 transition-all duration-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
              style={{ transitionDelay: `${300 + index * 80}ms` }}
            >
              {/* Tags */}
              <div className="flex gap-2 mb-3">
                {order.tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="bg-[#f7f7f7] text-[#74767e]">
                    {tag}
                  </Badge>
                ))}
              </div>

              {/* Title */}
              <h3 className="text-lg font-semibold text-[#404145] mb-3 line-clamp-2 hover:text-[#1dbf73] transition-colors">
                {order.title}
              </h3>

              {/* Description */}
              <p className="text-sm text-[#74767e] mb-4 line-clamp-2">
                {order.description}
              </p>

              {/* Details */}
              <div className="space-y-2 mb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-[#74767e]">
                    <Banknote className="w-4 h-4" />
                    <span className="text-sm">预算</span>
                  </div>
                  <span className="font-semibold text-[#1dbf73]">{order.budget}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-[#74767e]">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm">周期</span>
                  </div>
                  <span className="font-medium text-[#404145]">{order.duration}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-[#74767e]">
                    <Users className="w-4 h-4" />
                    <span className="text-sm">已投标</span>
                  </div>
                  <span className="font-medium text-[#404145]">{order.bids}人</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 text-[#74767e]">
                    <MapPin className="w-4 h-4" />
                    <span className="text-sm">地点</span>
                  </div>
                  <span className="font-medium text-[#404145]">{order.location}</span>
                </div>
              </div>

              {/* Client Info */}
              <div className="pt-4 border-t border-[#e4e5e7]">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-[#404145]">{order.client.name}</span>
                    <div className="flex items-center gap-1">
                      <Star className="w-3 h-3 fill-[#ffb33e] text-[#ffb33e]" />
                      <span className="text-xs text-[#74767e]">{order.client.rating}</span>
                    </div>
                  </div>
                  <span className="text-sm text-[#74767e]">{order.postedAt}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Empty State */}
        {filteredOrders.length === 0 && (
          <div className="text-center py-16">
            <div className="w-20 h-20 bg-[#f7f7f7] rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-10 h-10 text-[#74767e]" />
            </div>
            <h3 className="text-lg font-semibold text-[#404145] mb-2">没有找到相关订单</h3>
            <p className="text-[#74767e]">尝试调整筛选条件或搜索关键词</p>
          </div>
        )}
      </div>
    </div>
  )
}
