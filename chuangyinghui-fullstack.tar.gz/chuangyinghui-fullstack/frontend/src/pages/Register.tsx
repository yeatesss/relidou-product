import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { Eye, EyeOff, Mail, Lock, User, Phone } from 'lucide-react'
import { Button } from '@/components/ui/button'

export default function Register() {
  const navigate = useNavigate()
  const [isVisible, setIsVisible] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    email: '',
    password: '',
    confirmPassword: '',
    userType: 'client', // 'client' or 'creator'
    agree: false,
    code: '',
  })

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    alert('注册成功！')
    navigate('/login')
  }

  const sendCode = () => {
    alert('验证码已发送！')
  }

  return (
    <div className="min-h-screen bg-[#f7f7f7] pt-20 flex items-center justify-center py-12 px-4">
      <div className={`w-full max-w-md transition-all duration-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-[#1dbf73] rounded-xl flex items-center justify-center mx-auto mb-4">
            <span className="text-white font-bold text-2xl">创</span>
          </div>
          <h1 className="text-2xl font-bold text-[#404145]">创建账号</h1>
          <p className="text-[#74767e] mt-1">加入创影汇，开启视频创作之旅</p>
        </div>

        {/* Form */}
        <div className="bg-white rounded-xl p-8 shadow-sm">
          {/* User Type Tabs */}
          <div className="flex gap-2 mb-6">
            <button
              onClick={() => setFormData({ ...formData, userType: 'client' })}
              className={`flex-1 py-2.5 rounded-lg border transition-all ${
                formData.userType === 'client'
                  ? 'bg-[#1dbf73] text-white border-[#1dbf73]'
                  : 'border-[#e4e5e7] text-[#404145] hover:border-[#1dbf73]'
              }`}
            >
              我是甲方
            </button>
            <button
              onClick={() => setFormData({ ...formData, userType: 'creator' })}
              className={`flex-1 py-2.5 rounded-lg border transition-all ${
                formData.userType === 'creator'
                  ? 'bg-[#1dbf73] text-white border-[#1dbf73]'
                  : 'border-[#e4e5e7] text-[#404145] hover:border-[#1dbf73]'
              }`}
            >
              我是创作者
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-[#404145] mb-2">
                姓名
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#74767e]" />
                <input
                  type="text"
                  placeholder="请输入您的姓名"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full pl-10 pr-4 py-3 border border-[#e4e5e7] rounded-lg focus:outline-none focus:border-[#1dbf73] focus:ring-2 focus:ring-[#1dbf73]/20"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-[#404145] mb-2">
                手机号
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#74767e]" />
                <input
                  type="tel"
                  placeholder="请输入手机号"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full pl-10 pr-4 py-3 border border-[#e4e5e7] rounded-lg focus:outline-none focus:border-[#1dbf73] focus:ring-2 focus:ring-[#1dbf73]/20"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-[#404145] mb-2">
                邮箱
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#74767e]" />
                <input
                  type="email"
                  placeholder="请输入邮箱"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="w-full pl-10 pr-4 py-3 border border-[#e4e5e7] rounded-lg focus:outline-none focus:border-[#1dbf73] focus:ring-2 focus:ring-[#1dbf73]/20"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-[#404145] mb-2">
                验证码
              </label>
              <div className="flex gap-3">
                <input
                  type="text"
                  placeholder="请输入验证码"
                  value={formData.code}
                  onChange={(e) => setFormData({ ...formData, code: e.target.value })}
                  className="flex-1 px-4 py-3 border border-[#e4e5e7] rounded-lg focus:outline-none focus:border-[#1dbf73] focus:ring-2 focus:ring-[#1dbf73]/20"
                />
                <Button
                  type="button"
                  onClick={sendCode}
                  variant="outline"
                  className="border-[#1dbf73] text-[#1dbf73] hover:bg-[#1dbf73] hover:text-white"
                >
                  获取验证码
                </Button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-[#404145] mb-2">
                密码
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#74767e]" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="请设置密码（6-20位）"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="w-full pl-10 pr-12 py-3 border border-[#e4e5e7] rounded-lg focus:outline-none focus:border-[#1dbf73] focus:ring-2 focus:ring-[#1dbf73]/20"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#74767e] hover:text-[#404145]"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-[#404145] mb-2">
                确认密码
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-[#74767e]" />
                <input
                  type={showPassword ? 'text' : 'password'}
                  placeholder="请再次输入密码"
                  value={formData.confirmPassword}
                  onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                  className="w-full pl-10 pr-4 py-3 border border-[#e4e5e7] rounded-lg focus:outline-none focus:border-[#1dbf73] focus:ring-2 focus:ring-[#1dbf73]/20"
                />
              </div>
            </div>

            <label className="flex items-start gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={formData.agree}
                onChange={(e) => setFormData({ ...formData, agree: e.target.checked })}
                className="w-4 h-4 mt-0.5 rounded border-[#e4e5e7] text-[#1dbf73] focus:ring-[#1dbf73]"
              />
              <span className="text-sm text-[#74767e]">
                我已阅读并同意{' '}
                <a href="#" className="text-[#1dbf73] hover:underline">用户协议</a>
                {' '}和{' '}
                <a href="#" className="text-[#1dbf73] hover:underline">隐私政策</a>
              </span>
            </label>

            <Button
              type="submit"
              className="w-full bg-[#1dbf73] hover:bg-[#19a463] text-white py-3"
            >
              注册
            </Button>
          </form>
        </div>

        {/* Login Link */}
        <p className="text-center mt-6 text-[#74767e]">
          已有账号？{' '}
          <button
            onClick={() => navigate('/login')}
            className="text-[#1dbf73] font-medium hover:underline"
          >
            立即登录
          </button>
        </p>
      </div>
    </div>
  )
}
