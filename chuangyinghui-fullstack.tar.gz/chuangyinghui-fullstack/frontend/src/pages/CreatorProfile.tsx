import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { ArrowLeft, Star, CheckCircle, MapPin, Briefcase, Calendar, MessageCircle, Heart, Share2, Award } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

const creatorData = {
  id: 1,
  name: '小明影视',
  avatar: '/images/creator-1.jpg',
  title: '资深视频剪辑师',
  rating: 4.9,
  orders: 328,
  completionRate: 98,
  onTimeRate: 96,
  responseTime: '2小时内',
  startingPrice: 300,
  location: '北京',
  skills: ['剪辑', '调色', '特效', '字幕', '配音'],
  tags: ['抖音', '宣传片', 'Vlog', '电商视频'],
  verified: true,
  joinedAt: '2023-03-15',
  description: `专业视频剪辑师，5年行业经验，服务过众多知名品牌。

擅长各类视频制作：
- 抖音/快手短视频
- 企业宣传片
- 产品展示视频
- 个人Vlog
- 婚礼/活动记录

使用专业软件：Premiere Pro, After Effects, DaVinci Resolve

承诺：高质量交付，快速响应，免费修改到满意为止。`,
  portfolio: [
    { id: 1, title: '美妆品牌抖音视频', type: 'video', views: '12.5万' },
    { id: 2, title: '科技企业宣传片', type: 'video', views: '8.3万' },
    { id: 3, title: '产品开箱测评', type: 'video', views: '5.6万' },
    { id: 4, title: '旅行Vlog剪辑', type: 'video', views: '3.2万' },
    { id: 5, title: '电商主图视频', type: 'video', views: '15.8万' },
    { id: 6, title: '婚礼纪录片', type: 'video', views: '2.1万' },
  ],
  services: [
    { name: '抖音短视频剪辑', price: '¥300起', delivery: '1-2天' },
    { name: '企业宣传片制作', price: '¥2000起', delivery: '5-7天' },
    { name: '产品展示视频', price: '¥800起', delivery: '2-3天' },
    { name: 'Vlog剪辑', price: '¥500起', delivery: '2-3天' },
  ],
  reviews: [
    {
      id: 1,
      author: '张女士',
      rating: 5,
      content: '非常专业的剪辑师，交付速度快，质量也很高，强烈推荐！',
      date: '2026-02-20',
      order: '美妆品牌抖音视频',
    },
    {
      id: 2,
      author: '李先生',
      rating: 5,
      content: '合作很愉快，沟通顺畅，视频效果超出预期。',
      date: '2026-02-15',
      order: '企业宣传片',
    },
    {
      id: 3,
      author: '王小姐',
      rating: 4,
      content: '整体不错，修改了几次后达到满意效果。',
      date: '2026-02-10',
      order: '产品展示视频',
    },
  ],
}

export default function CreatorProfile() {
  const { id } = useParams()
  console.log('Creator ID:', id)
  const navigate = useNavigate()
  const [isVisible, setIsVisible] = useState(false)
  const [activeTab, setActiveTab] = useState('portfolio')

  useEffect(() => {
    setIsVisible(true)
  }, [])

  return (
    <div className="min-h-screen bg-[#f7f7f7] pt-20">
      {/* Header */}
      <div className="bg-white border-b border-[#e4e5e7]">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={() => navigate('/creators')}
            className="flex items-center gap-2 text-[#74767e] hover:text-[#1dbf73] transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            返回创作者列表
          </button>
        </div>
      </div>

      {/* Profile Header */}
      <div className="bg-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className={`flex flex-col md:flex-row gap-6 transition-all duration-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
            {/* Avatar */}
            <div className="relative">
              <Avatar className="w-32 h-32 border-4 border-[#f7f7f7]">
                <AvatarImage src={creatorData.avatar} alt={creatorData.name} />
                <AvatarFallback className="text-3xl">{creatorData.name[0]}</AvatarFallback>
              </Avatar>
              {creatorData.verified && (
                <div className="absolute bottom-0 right-0 w-8 h-8 bg-[#1dbf73] rounded-full flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-white" />
                </div>
              )}
            </div>

            {/* Info */}
            <div className="flex-1">
              <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                <div>
                  <h1 className="text-2xl font-bold text-[#404145] mb-1">{creatorData.name}</h1>
                  <p className="text-[#74767e] mb-3">{creatorData.title}</p>
                  
                  {/* Stats */}
                  <div className="flex flex-wrap items-center gap-4 mb-4">
                    <div className="flex items-center gap-1">
                      <Star className="w-5 h-5 fill-[#ffb33e] text-[#ffb33e]" />
                      <span className="font-semibold text-[#404145]">{creatorData.rating}</span>
                      <span className="text-[#74767e]">评分</span>
                    </div>
                    <div className="flex items-center gap-1 text-[#74767e]">
                      <Briefcase className="w-5 h-5" />
                      <span>{creatorData.orders}单</span>
                    </div>
                    <div className="flex items-center gap-1 text-[#74767e]">
                      <MapPin className="w-5 h-5" />
                      <span>{creatorData.location}</span>
                    </div>
                    <div className="flex items-center gap-1 text-[#74767e]">
                      <Calendar className="w-5 h-5" />
                      <span>入驻{creatorData.joinedAt.slice(0, 4)}年</span>
                    </div>
                  </div>

                  {/* Skills */}
                  <div className="flex flex-wrap gap-2">
                    {creatorData.skills.map((skill) => (
                      <Badge key={skill} variant="secondary" className="bg-[#f7f7f7] text-[#74767e]">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-col gap-3">
                  <Button className="bg-[#1dbf73] hover:bg-[#19a463] text-white px-8">
                    <MessageCircle className="w-4 h-4 mr-2" />
                    联系TA
                  </Button>
                  <div className="flex gap-2">
                    <Button variant="outline" className="flex-1 border-[#e4e5e7]">
                      <Heart className="w-4 h-4 mr-2" />
                      关注
                    </Button>
                    <Button variant="outline" className="flex-1 border-[#e4e5e7]">
                      <Share2 className="w-4 h-4 mr-2" />
                      分享
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Bar */}
      <div className="bg-[#f7f7f7] border-b border-[#e4e5e7]">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className={`grid grid-cols-2 md:grid-cols-4 gap-4 transition-all duration-500 delay-100 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#1dbf73]">{creatorData.completionRate}%</div>
              <div className="text-sm text-[#74767e]">订单完成率</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#1dbf73]">{creatorData.onTimeRate}%</div>
              <div className="text-sm text-[#74767e]">准时交付率</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#1dbf73]">{creatorData.responseTime}</div>
              <div className="text-sm text-[#74767e]">平均响应</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#1dbf73]">¥{creatorData.startingPrice}</div>
              <div className="text-sm text-[#74767e]">起步价</div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className={`transition-all duration-500 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="w-full bg-white mb-6">
              <TabsTrigger value="portfolio" className="flex-1">作品集</TabsTrigger>
              <TabsTrigger value="services" className="flex-1">服务</TabsTrigger>
              <TabsTrigger value="about" className="flex-1">关于</TabsTrigger>
              <TabsTrigger value="reviews" className="flex-1">评价 ({creatorData.reviews.length})</TabsTrigger>
            </TabsList>

            {/* Portfolio */}
            <TabsContent value="portfolio">
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {creatorData.portfolio.map((item) => (
                  <div key={item.id} className="bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow cursor-pointer">
                    <div className="aspect-video bg-gradient-to-br from-[#003912] to-[#0a4226] flex items-center justify-center">
                      <div className="text-white text-center">
                        <div className="text-4xl mb-2">▶</div>
                        <div className="text-sm opacity-80">{item.views}次播放</div>
                      </div>
                    </div>
                    <div className="p-4">
                      <h3 className="font-medium text-[#404145]">{item.title}</h3>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            {/* Services */}
            <TabsContent value="services">
              <div className="space-y-4">
                {creatorData.services.map((service, index) => (
                  <div key={index} className="bg-white rounded-xl p-6 shadow-sm flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold text-[#404145] mb-1">{service.name}</h3>
                      <div className="flex items-center gap-4 text-sm text-[#74767e]">
                        <span>交付周期: {service.delivery}</span>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-[#1dbf73]">{service.price}</div>
                      <Button size="sm" className="mt-2 bg-[#1dbf73] hover:bg-[#19a463] text-white">
                        下单
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            {/* About */}
            <TabsContent value="about">
              <div className="bg-white rounded-xl p-6 shadow-sm">
                <h2 className="text-lg font-semibold text-[#404145] mb-4">个人简介</h2>
                <div className="text-[#74767e] whitespace-pre-line leading-relaxed">
                  {creatorData.description}
                </div>
                
                <h2 className="text-lg font-semibold text-[#404145] mt-8 mb-4">擅长领域</h2>
                <div className="flex flex-wrap gap-2">
                  {creatorData.tags.map((tag) => (
                    <Badge key={tag} className="bg-[#1dbf73]/10 text-[#1dbf73] hover:bg-[#1dbf73]/20">
                      {tag}
                    </Badge>
                  ))}
                </div>

                <h2 className="text-lg font-semibold text-[#404145] mt-8 mb-4">认证信息</h2>
                <div className="flex items-center gap-2 text-[#74767e]">
                  <Award className="w-5 h-5 text-[#1dbf73]" />
                  <span>平台认证创作者</span>
                </div>
              </div>
            </TabsContent>

            {/* Reviews */}
            <TabsContent value="reviews">
              <div className="space-y-4">
                {creatorData.reviews.map((review) => (
                  <div key={review.id} className="bg-white rounded-xl p-6 shadow-sm">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <span className="font-semibold text-[#404145]">{review.author}</span>
                      </div>
                      <span className="text-sm text-[#74767e]">{review.date}</span>
                    </div>
                    <div className="flex items-center gap-1 mb-3">
                      {[...Array(review.rating)].map((_, i) => (
                        <Star key={i} className="w-4 h-4 fill-[#ffb33e] text-[#ffb33e]" />
                      ))}
                    </div>
                    <p className="text-[#74767e] mb-2">{review.content}</p>
                    <Badge variant="secondary" className="bg-[#f7f7f7] text-[#74767e]">
                      {review.order}
                    </Badge>
                  </div>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
