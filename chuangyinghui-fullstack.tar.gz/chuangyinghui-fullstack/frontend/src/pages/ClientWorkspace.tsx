import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  LayoutDashboard,
  ShoppingCart,
  Users,
  MessageSquare,
  Wallet,
  Star,
  Plus,
  Search,
  Eye,
  CheckCircle,
  Clock,
  DollarSign,
  ChevronRight,
  TrendingUp,
} from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'

const stats = [
  { title: '我的订单', value: '12', icon: ShoppingCart, color: 'bg-blue-500' },
  { title: '进行中', value: '3', icon: Clock, color: 'bg-yellow-500' },
  { title: '已完成', value: '8', icon: CheckCircle, color: 'bg-green-500' },
  { title: '总支出', value: '¥45,800', icon: DollarSign, color: 'bg-[#1dbf73]' },
]

const myOrders = [
  { id: 'ORD-2026-001', title: '美妆品牌抖音短视频', budget: '¥800-1500', finalPrice: '¥1,200', status: '进行中', bids: 5, creator: '小明影视', deadline: '2026-02-26', createdAt: '2026-02-23' },
  { id: 'ORD-2026-002', title: '产品展示视频拍摄', budget: '¥1,500-3,000', finalPrice: '¥2,500', status: '待确认', bids: 3, creator: null, deadline: '2026-02-27', createdAt: '2026-02-22' },
  { id: 'ORD-2026-003', title: '企业宣传片剪辑', budget: '¥3,000-8,000', finalPrice: '¥5,000', status: '已完成', bids: 8, creator: '动画工坊', deadline: '2026-02-25', createdAt: '2026-02-20' },
  { id: 'ORD-2026-004', title: 'APP演示动画', budget: '¥5,000-10,000', finalPrice: '¥8,000', status: '进行中', bids: 6, creator: '三维视界', deadline: '2026-03-01', createdAt: '2026-02-19' },
]

const myBids = [
  { id: 1, creator: '小明影视', avatar: '/images/creator-1.jpg', order: '美妆品牌抖音短视频', price: '¥1,200', duration: '2天', message: '有丰富的抖音短视频拍摄经验...', submittedAt: '2小时前', status: '已中标' },
  { id: 2, creator: '视频达人', avatar: '/images/creator-1.jpg', order: '产品展示视频拍摄', price: '¥2,200', duration: '3天', message: '专业产品摄影师，设备齐全...', submittedAt: '5小时前', status: '待选择' },
  { id: 3, creator: '创意工作室', avatar: '/images/creator-3.jpg', order: '产品展示视频拍摄', price: '¥2,800', duration: '4天', message: '团队服务，从拍摄到后期一站式...', submittedAt: '1天前', status: '待选择' },
]

const myCreators = [
  { id: 1, name: '小明影视', avatar: '/images/creator-1.jpg', title: '资深视频剪辑师', rating: 4.9, orders: 328, cooperations: 3, lastCooperation: '2026-02-20' },
  { id: 2, name: '动画工坊', avatar: '/images/creator-3.jpg', title: 'MG动画设计师', rating: 5.0, orders: 89, cooperations: 2, lastCooperation: '2026-02-15' },
  { id: 3, name: '三维视界', avatar: '/images/creator-3.jpg', title: '3D设计师', rating: 4.9, orders: 67, cooperations: 1, lastCooperation: '2026-01-28' },
]

const messages = [
  { id: 1, from: '小明影视', avatar: '/images/creator-1.jpg', content: '好的，我会按照您的要求修改', time: '10:30', unread: true },
  { id: 2, from: '动画工坊', avatar: '/images/creator-3.jpg', content: '初稿已经发给您了，请查收', time: '昨天', unread: false },
]

const transactions = [
  { id: 1, type: '支出', title: '企业宣传片剪辑', amount: '-¥5,000', date: '2026-02-20', status: '已完成' },
  { id: 2, type: '支出', title: '美妆短视频拍摄', amount: '-¥1,200', date: '2026-02-18', status: '已完成' },
  { id: 3, type: '充值', title: '账户充值', amount: '+¥10,000', date: '2026-02-15', status: '已完成' },
]

const getStatusColor = (status: string) => {
  switch (status) {
    case '进行中':
      return 'bg-blue-100 text-blue-700'
    case '待确认':
      return 'bg-yellow-100 text-yellow-700'
    case '已完成':
      return 'bg-green-100 text-green-700'
    case '已中标':
      return 'bg-green-100 text-green-700'
    case '待选择':
      return 'bg-blue-100 text-blue-700'
    default:
      return 'bg-slate-100 text-slate-700'
  }
}

export default function ClientWorkspace() {
  const navigate = useNavigate()
  const [activeTab, setActiveTab] = useState('overview')
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    setIsVisible(true)
  }, [])

  return (
    <div className="min-h-screen bg-[#f7f7f7] pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className={`flex items-center justify-between mb-8 transition-all duration-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
          <div>
            <h1 className="text-2xl font-bold text-[#404145]">我的工作台</h1>
            <p className="text-[#74767e] mt-1">欢迎回来，管理您的订单和创作者</p>
          </div>
          <div className="flex gap-3">
            <Button
              onClick={() => navigate('/post-order')}
              className="bg-[#1dbf73] hover:bg-[#19a463] text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              发布订单
            </Button>
            <Button
              variant="outline"
              onClick={() => navigate('/creators')}
              className="border-[#e4e5e7]"
            >
              <Search className="w-4 h-4 mr-2" />
              找创作者
            </Button>
          </div>
        </div>

        {/* Stats */}
        <div className={`grid grid-cols-2 md:grid-cols-4 gap-4 mb-8 transition-all duration-500 delay-100 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
          {stats.map((stat) => {
            const Icon = stat.icon
            return (
              <div key={stat.title} className="bg-white rounded-xl p-5 shadow-sm border border-slate-100">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-[#74767e] text-sm">{stat.title}</p>
                    <p className="text-2xl font-bold text-[#404145] mt-1">{stat.value}</p>
                  </div>
                  <div className={`w-12 h-12 ${stat.color} rounded-xl flex items-center justify-center`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        {/* Main Content */}
        <div className={`transition-all duration-500 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="bg-white mb-6 p-1 rounded-xl">
              <TabsTrigger value="overview" className="rounded-lg data-[state=active]:bg-[#1dbf73] data-[state=active]:text-white">
                <LayoutDashboard className="w-4 h-4 mr-2" />
                概览
              </TabsTrigger>
              <TabsTrigger value="orders" className="rounded-lg data-[state=active]:bg-[#1dbf73] data-[state=active]:text-white">
                <ShoppingCart className="w-4 h-4 mr-2" />
                我的订单
              </TabsTrigger>
              <TabsTrigger value="bids" className="rounded-lg data-[state=active]:bg-[#1dbf73] data-[state=active]:text-white">
                <TrendingUp className="w-4 h-4 mr-2" />
                投标管理
              </TabsTrigger>
              <TabsTrigger value="creators" className="rounded-lg data-[state=active]:bg-[#1dbf73] data-[state=active]:text-white">
                <Users className="w-4 h-4 mr-2" />
                我的创作者
              </TabsTrigger>
              <TabsTrigger value="messages" className="rounded-lg data-[state=active]:bg-[#1dbf73] data-[state=active]:text-white">
                <MessageSquare className="w-4 h-4 mr-2" />
                消息
              </TabsTrigger>
              <TabsTrigger value="finance" className="rounded-lg data-[state=active]:bg-[#1dbf73] data-[state=active]:text-white">
                <Wallet className="w-4 h-4 mr-2" />
                财务
              </TabsTrigger>
            </TabsList>

            {/* Overview */}
            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Recent Orders */}
                <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                  <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                    <h3 className="font-semibold text-[#404145]">最近订单</h3>
                    <button onClick={() => setActiveTab('orders')} className="text-[#1dbf73] text-sm hover:underline flex items-center">
                      查看全部 <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="divide-y divide-slate-100">
                    {myOrders.slice(0, 3).map((order) => (
                      <div key={order.id} className="p-4 hover:bg-slate-50">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-medium text-[#404145]">{order.title}</p>
                            <p className="text-sm text-[#74767e] mt-1">{order.id} · {order.bids}人投标</p>
                          </div>
                          <div className="text-right">
                            <Badge className={getStatusColor(order.status)}>{order.status}</Badge>
                            <p className="text-[#1dbf73] font-medium mt-1">{order.finalPrice || order.budget}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* New Bids */}
                <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                  <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                    <h3 className="font-semibold text-[#404145]">最新投标</h3>
                    <button onClick={() => setActiveTab('bids')} className="text-[#1dbf73] text-sm hover:underline flex items-center">
                      查看全部 <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="divide-y divide-slate-100">
                    {myBids.slice(0, 3).map((bid) => (
                      <div key={bid.id} className="p-4 hover:bg-slate-50">
                        <div className="flex items-start gap-3">
                          <Avatar className="w-10 h-10">
                            <AvatarImage src={bid.avatar} />
                            <AvatarFallback>{bid.creator[0]}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <p className="font-medium text-[#404145]">{bid.creator}</p>
                              <Badge className={getStatusColor(bid.status)}>{bid.status}</Badge>
                            </div>
                            <p className="text-sm text-[#74767e]">{bid.order}</p>
                            <p className="text-sm text-[#1dbf73] font-medium mt-1">{bid.price} · {bid.duration}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Messages */}
                <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                  <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                    <h3 className="font-semibold text-[#404145]">未读消息</h3>
                    <button onClick={() => setActiveTab('messages')} className="text-[#1dbf73] text-sm hover:underline flex items-center">
                      查看全部 <ChevronRight className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="divide-y divide-slate-100">
                    {messages.filter(m => m.unread).map((msg) => (
                      <div key={msg.id} className="p-4 hover:bg-slate-50 bg-blue-50/30">
                        <div className="flex items-start gap-3">
                          <Avatar className="w-10 h-10">
                            <AvatarImage src={msg.avatar} />
                            <AvatarFallback>{msg.from[0]}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex items-center justify-between">
                              <p className="font-medium text-[#404145]">{msg.from}</p>
                              <span className="w-2 h-2 bg-red-500 rounded-full" />
                            </div>
                            <p className="text-sm text-[#74767e] truncate">{msg.content}</p>
                            <p className="text-xs text-[#74767e] mt-1">{msg.time}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Quick Actions */}
                <div className="bg-white rounded-xl shadow-sm border border-slate-100 p-5">
                  <h3 className="font-semibold text-[#404145] mb-4">快捷操作</h3>
                  <div className="grid grid-cols-2 gap-3">
                    <button onClick={() => navigate('/post-order')} className="p-4 bg-[#1dbf73]/10 rounded-xl text-center hover:bg-[#1dbf73]/20 transition-colors">
                      <Plus className="w-6 h-6 text-[#1dbf73] mx-auto mb-2" />
                      <p className="text-sm font-medium text-[#404145]">发布订单</p>
                    </button>
                    <button onClick={() => navigate('/creators')} className="p-4 bg-blue-50 rounded-xl text-center hover:bg-blue-100 transition-colors">
                      <Search className="w-6 h-6 text-blue-500 mx-auto mb-2" />
                      <p className="text-sm font-medium text-[#404145]">找创作者</p>
                    </button>
                    <button onClick={() => setActiveTab('orders')} className="p-4 bg-purple-50 rounded-xl text-center hover:bg-purple-100 transition-colors">
                      <Eye className="w-6 h-6 text-purple-500 mx-auto mb-2" />
                      <p className="text-sm font-medium text-[#404145]">查看订单</p>
                    </button>
                    <button onClick={() => setActiveTab('finance')} className="p-4 bg-green-50 rounded-xl text-center hover:bg-green-100 transition-colors">
                      <Wallet className="w-6 h-6 text-green-500 mx-auto mb-2" />
                      <p className="text-sm font-medium text-[#404145]">账户充值</p>
                    </button>
                  </div>
                </div>
              </div>
            </TabsContent>

            {/* Orders */}
            <TabsContent value="orders">
              <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="p-5 border-b border-slate-100">
                  <div className="flex items-center gap-4">
                    <input
                      type="text"
                      placeholder="搜索订单..."
                      className="flex-1 max-w-md px-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-[#1dbf73]"
                    />
                    <select className="px-4 py-2 border border-slate-200 rounded-lg text-sm focus:outline-none focus:border-[#1dbf73]">
                      <option>全部状态</option>
                      <option>进行中</option>
                      <option>待确认</option>
                      <option>已完成</option>
                    </select>
                  </div>
                </div>
                <table className="w-full">
                  <thead className="bg-slate-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">订单信息</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">预算/成交价</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">创作者</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">状态</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">截止日</th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">操作</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {myOrders.map((order) => (
                      <tr key={order.id} className="hover:bg-slate-50">
                        <td className="px-6 py-4">
                          <p className="font-medium text-[#404145]">{order.title}</p>
                          <p className="text-sm text-[#74767e]">{order.id}</p>
                        </td>
                        <td className="px-6 py-4">
                          <p className="text-sm text-[#74767e] line-through">{order.budget}</p>
                          <p className="text-[#1dbf73] font-medium">{order.finalPrice}</p>
                        </td>
                        <td className="px-6 py-4 text-sm text-slate-600">{order.creator || '-'}</td>
                        <td className="px-6 py-4">
                          <Badge className={getStatusColor(order.status)}>{order.status}</Badge>
                        </td>
                        <td className="px-6 py-4 text-sm text-slate-500">{order.deadline}</td>
                        <td className="px-6 py-4">
                          <div className="flex gap-1">
                            <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-500">
                              <Eye className="w-4 h-4" />
                            </button>
                            <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-500">
                              <MessageSquare className="w-4 h-4" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </TabsContent>

            {/* Bids */}
            <TabsContent value="bids">
              <div className="space-y-4">
                {myBids.map((bid) => (
                  <div key={bid.id} className="bg-white rounded-xl p-5 shadow-sm border border-slate-100">
                    <div className="flex items-start gap-4">
                      <Avatar className="w-14 h-14">
                        <AvatarImage src={bid.avatar} />
                        <AvatarFallback>{bid.creator[0]}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="font-semibold text-[#404145]">{bid.creator}</p>
                            <p className="text-sm text-[#74767e]">投标订单：{bid.order}</p>
                          </div>
                          <Badge className={getStatusColor(bid.status)}>{bid.status}</Badge>
                        </div>
                        <div className="mt-3 p-3 bg-slate-50 rounded-lg">
                          <p className="text-sm text-[#74767e]">{bid.message}</p>
                        </div>
                        <div className="flex items-center justify-between mt-3">
                          <div className="flex items-center gap-4">
                            <span className="text-lg font-bold text-[#1dbf73]">{bid.price}</span>
                            <span className="text-sm text-[#74767e]">交付周期：{bid.duration}</span>
                            <span className="text-sm text-[#74767e]">{bid.submittedAt}</span>
                          </div>
                          {bid.status === '待选择' && (
                            <div className="flex gap-2">
                              <Button size="sm" className="bg-[#1dbf73] hover:bg-[#19a463]">
                                选择合作
                              </Button>
                              <Button size="sm" variant="outline" className="border-slate-200">
                                查看主页
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            {/* Creators */}
            <TabsContent value="creators">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {myCreators.map((creator) => (
                  <div key={creator.id} className="bg-white rounded-xl p-5 shadow-sm border border-slate-100">
                    <div className="flex items-center gap-4">
                      <Avatar className="w-16 h-16">
                        <AvatarImage src={creator.avatar} />
                        <AvatarFallback>{creator.name[0]}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-semibold text-[#404145]">{creator.name}</p>
                        <p className="text-sm text-[#74767e]">{creator.title}</p>
                        <div className="flex items-center gap-1 mt-1">
                          <Star className="w-4 h-4 fill-amber-500 text-amber-500" />
                          <span className="text-sm font-medium">{creator.rating}</span>
                          <span className="text-sm text-[#74767e]">· {creator.orders}单</span>
                        </div>
                      </div>
                    </div>
                    <div className="mt-4 pt-4 border-t border-slate-100">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-[#74767e]">合作次数</span>
                        <span className="font-medium text-[#404145]">{creator.cooperations}次</span>
                      </div>
                      <div className="flex items-center justify-between text-sm mt-2">
                        <span className="text-[#74767e]">最近合作</span>
                        <span className="font-medium text-[#404145]">{creator.lastCooperation}</span>
                      </div>
                    </div>
                    <div className="mt-4 flex gap-2">
                      <Button size="sm" className="flex-1 bg-[#1dbf73] hover:bg-[#19a463]">
                        <Plus className="w-4 h-4 mr-1" />
                        发订单
                      </Button>
                      <Button size="sm" variant="outline" className="flex-1 border-slate-200">
                        <MessageSquare className="w-4 h-4 mr-1" />
                        联系
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>

            {/* Messages */}
            <TabsContent value="messages">
              <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                <div className="divide-y divide-slate-100">
                  {messages.map((msg) => (
                    <div key={msg.id} className={`p-4 hover:bg-slate-50 cursor-pointer ${msg.unread ? 'bg-blue-50/30' : ''}`}>
                      <div className="flex items-start gap-4">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={msg.avatar} />
                          <AvatarFallback>{msg.from[0]}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <p className="font-medium text-[#404145]">{msg.from}</p>
                            <span className="text-sm text-[#74767e]">{msg.time}</span>
                          </div>
                          <p className="text-sm text-[#74767e] mt-1">{msg.content}</p>
                        </div>
                        {msg.unread && <span className="w-2 h-2 bg-red-500 rounded-full" />}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>

            {/* Finance */}
            <TabsContent value="finance">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                  <div className="bg-white rounded-xl shadow-sm border border-slate-100 overflow-hidden">
                    <div className="p-5 border-b border-slate-100">
                      <h3 className="font-semibold text-[#404145]">交易记录</h3>
                    </div>
                    <table className="w-full">
                      <thead className="bg-slate-50">
                        <tr>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">类型</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">项目</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">金额</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">日期</th>
                          <th className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase">状态</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {transactions.map((tx) => (
                          <tr key={tx.id} className="hover:bg-slate-50">
                            <td className="px-6 py-4">
                              <Badge variant="secondary" className={tx.type === '充值' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}>
                                {tx.type}
                              </Badge>
                            </td>
                            <td className="px-6 py-4 text-sm text-[#404145]">{tx.title}</td>
                            <td className={`px-6 py-4 font-medium ${tx.amount.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>
                              {tx.amount}
                            </td>
                            <td className="px-6 py-4 text-sm text-slate-500">{tx.date}</td>
                            <td className="px-6 py-4">
                              <Badge className="bg-green-100 text-green-700">{tx.status}</Badge>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-100">
                    <p className="text-[#74767e] text-sm">账户余额</p>
                    <p className="text-3xl font-bold text-[#404145] mt-2">¥12,500</p>
                    <Button className="w-full mt-4 bg-[#1dbf73] hover:bg-[#19a463]">
                      立即充值
                    </Button>
                  </div>

                  <div className="bg-white rounded-xl p-5 shadow-sm border border-slate-100">
                    <p className="text-[#74767e] text-sm">本月支出</p>
                    <p className="text-2xl font-bold text-red-500 mt-2">¥6,200</p>
                    <p className="text-sm text-[#74767e] mt-1">较上月 +15%</p>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
