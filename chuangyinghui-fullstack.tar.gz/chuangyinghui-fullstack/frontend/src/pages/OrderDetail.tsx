import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { ArrowLeft, Clock, Users, Banknote, MapPin, Calendar, Star, MessageCircle, Share2, Flag } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Avatar, AvatarImage, AvatarFallback } from '@/components/ui/avatar'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog'

const orderData = {
  id: 1,
  title: '美妆品牌抖音短视频拍摄',
  budget: '¥800-1500',
  budgetMin: 800,
  budgetMax: 1500,
  duration: '3天',
  bids: 12,
  tags: ['短视频', '美妆'],
  postedAt: '2026-02-23 14:30',
  deadline: '2026-02-26',
  location: '全国',
  status: '进行中',
  description: `我们需要为新款口红产品拍摄3条15-30秒的抖音短视频。

【视频要求】
1. 真人出镜，展示产品使用效果
2. 风格年轻化、时尚化
3. 需要有创意的产品展示方式
4. 视频需适合抖音平台传播

【交付内容】
- 3条15-30秒竖版视频
- 原片素材（如有需要）
- 剪辑后的成品视频

【参考风格】
类似完美日记、花西子品牌的短视频风格，突出产品卖点，有记忆点。`,
  requirements: [
    '有美妆产品拍摄经验',
    '熟悉抖音平台内容风格',
    '有良好的镜头表现力',
    '能按时交付高质量作品',
  ],
  client: {
    name: '花漾美妆',
    avatar: '/images/creator-2.jpg',
    rating: 4.8,
    orders: 23,
    joinedAt: '2025-06-15',
    description: '专注美妆产品研发的新兴品牌，致力于为消费者提供高品质的美妆产品。',
  },
}

const bids = [
  {
    id: 1,
    creator: {
      name: '小美摄影',
      avatar: '/images/creator-2.jpg',
      rating: 4.9,
      orders: 156,
    },
    price: '¥1200',
    duration: '2天',
    message: '有丰富的抖音短视频拍摄经验，曾为多个美妆品牌拍摄产品视频，可以查看我的作品集。',
    submittedAt: '2小时前',
  },
  {
    id: 2,
    creator: {
      name: '视频达人',
      avatar: '/images/creator-1.jpg',
      rating: 4.7,
      orders: 89,
    },
    price: '¥1000',
    duration: '3天',
    message: '专业短视频创作者，熟悉抖音算法，能制作出高传播度的内容。',
    submittedAt: '5小时前',
  },
  {
    id: 3,
    creator: {
      name: '创意工作室',
      avatar: '/images/creator-3.jpg',
      rating: 5.0,
      orders: 234,
    },
    price: '¥1500',
    duration: '2天',
    message: '团队服务，从脚本到拍摄到后期一站式完成，保证高质量交付。',
    submittedAt: '1天前',
  },
]

export default function OrderDetail() {
  const { id } = useParams()
  console.log('Order ID:', id)
  const navigate = useNavigate()
  const [isVisible, setIsVisible] = useState(false)
  const [showBidDialog, setShowBidDialog] = useState(false)
  const [bidPrice, setBidPrice] = useState('')
  const [bidDuration, setBidDuration] = useState('')
  const [bidMessage, setBidMessage] = useState('')

  useEffect(() => {
    setIsVisible(true)
  }, [])

  const handleSubmitBid = () => {
    alert('投标提交成功！')
    setShowBidDialog(false)
  }

  return (
    <div className="min-h-screen bg-[#f7f7f7] pt-20">
      {/* Header */}
      <div className="bg-white border-b border-[#e4e5e7]">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={() => navigate('/orders')}
            className="flex items-center gap-2 text-[#74767e] hover:text-[#1dbf73] transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            返回订单列表
          </button>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Order Card */}
            <div className={`bg-white rounded-xl p-6 shadow-sm transition-all duration-500 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
              {/* Tags */}
              <div className="flex gap-2 mb-4">
                {orderData.tags.map((tag) => (
                  <Badge key={tag} variant="secondary" className="bg-[#f7f7f7] text-[#74767e]">
                    {tag}
                  </Badge>
                ))}
                <Badge className="bg-[#1dbf73] text-white">{orderData.status}</Badge>
              </div>

              {/* Title */}
              <h1 className="text-2xl font-bold text-[#404145] mb-4">
                {orderData.title}
              </h1>

              {/* Key Info */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="bg-[#f7f7f7] rounded-lg p-4">
                  <div className="flex items-center gap-2 text-[#74767e] mb-1">
                    <Banknote className="w-4 h-4" />
                    <span className="text-sm">预算</span>
                  </div>
                  <div className="text-lg font-bold text-[#1dbf73]">{orderData.budget}</div>
                </div>
                <div className="bg-[#f7f7f7] rounded-lg p-4">
                  <div className="flex items-center gap-2 text-[#74767e] mb-1">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm">周期</span>
                  </div>
                  <div className="text-lg font-bold text-[#404145]">{orderData.duration}</div>
                </div>
                <div className="bg-[#f7f7f7] rounded-lg p-4">
                  <div className="flex items-center gap-2 text-[#74767e] mb-1">
                    <Users className="w-4 h-4" />
                    <span className="text-sm">投标</span>
                  </div>
                  <div className="text-lg font-bold text-[#404145]">{orderData.bids}人</div>
                </div>
                <div className="bg-[#f7f7f7] rounded-lg p-4">
                  <div className="flex items-center gap-2 text-[#74767e] mb-1">
                    <MapPin className="w-4 h-4" />
                    <span className="text-sm">地点</span>
                  </div>
                  <div className="text-lg font-bold text-[#404145]">{orderData.location}</div>
                </div>
              </div>

              {/* Description */}
              <div className="mb-6">
                <h2 className="text-lg font-semibold text-[#404145] mb-3">需求描述</h2>
                <div className="text-[#74767e] whitespace-pre-line leading-relaxed">
                  {orderData.description}
                </div>
              </div>

              {/* Requirements */}
              <div>
                <h2 className="text-lg font-semibold text-[#404145] mb-3">创作者要求</h2>
                <ul className="space-y-2">
                  {orderData.requirements.map((req, index) => (
                    <li key={index} className="flex items-center gap-2 text-[#74767e]">
                      <div className="w-1.5 h-1.5 bg-[#1dbf73] rounded-full" />
                      {req}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Bids Section */}
            <div className={`bg-white rounded-xl p-6 shadow-sm transition-all duration-500 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
              <h2 className="text-lg font-semibold text-[#404145] mb-4">
                投标记录 ({bids.length})
              </h2>
              <div className="space-y-4">
                {bids.map((bid) => (
                  <div key={bid.id} className="border border-[#e4e5e7] rounded-lg p-4 hover:border-[#1dbf73]/30 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex items-center gap-3">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={bid.creator.avatar} alt={bid.creator.name} />
                          <AvatarFallback>{bid.creator.name[0]}</AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-semibold text-[#404145]">{bid.creator.name}</div>
                          <div className="flex items-center gap-2 text-sm text-[#74767e]">
                            <Star className="w-3 h-3 fill-[#ffb33e] text-[#ffb33e]" />
                            <span>{bid.creator.rating}</span>
                            <span>·</span>
                            <span>{bid.creator.orders}单</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-xl font-bold text-[#1dbf73]">{bid.price}</div>
                        <div className="text-sm text-[#74767e]">{bid.duration}</div>
                      </div>
                    </div>
                    <p className="mt-3 text-[#74767e] text-sm">{bid.message}</p>
                    <div className="mt-3 flex items-center justify-between">
                      <span className="text-sm text-[#74767e]">{bid.submittedAt}</span>
                      <Button size="sm" variant="outline" className="border-[#1dbf73] text-[#1dbf73] hover:bg-[#1dbf73] hover:text-white">
                        查看方案
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Action Card */}
            <div className={`bg-white rounded-xl p-6 shadow-sm transition-all duration-500 delay-100 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
              <Button
                onClick={() => setShowBidDialog(true)}
                className="w-full bg-[#1dbf73] hover:bg-[#19a463] text-white py-6 text-lg font-semibold"
              >
                立即投标
              </Button>
              <div className="mt-4 flex gap-2">
                <Button variant="outline" className="flex-1 border-[#e4e5e7]">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  咨询
                </Button>
                <Button variant="outline" className="flex-1 border-[#e4e5e7]">
                  <Share2 className="w-4 h-4 mr-2" />
                  分享
                </Button>
              </div>
            </div>

            {/* Client Info */}
            <div className={`bg-white rounded-xl p-6 shadow-sm transition-all duration-500 delay-200 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
              <h3 className="font-semibold text-[#404145] mb-4">发布方信息</h3>
              <div className="flex items-center gap-3 mb-4">
                <Avatar className="w-16 h-16">
                  <AvatarImage src={orderData.client.avatar} alt={orderData.client.name} />
                  <AvatarFallback>{orderData.client.name[0]}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-semibold text-[#404145]">{orderData.client.name}</div>
                  <div className="flex items-center gap-1 text-sm text-[#74767e]">
                    <Star className="w-3 h-3 fill-[#ffb33e] text-[#ffb33e]" />
                    <span>{orderData.client.rating}</span>
                    <span>·</span>
                    <span>{orderData.client.orders}单</span>
                  </div>
                </div>
              </div>
              <p className="text-sm text-[#74767e] mb-4">{orderData.client.description}</p>
              <div className="text-sm text-[#74767e]">
                <Calendar className="w-4 h-4 inline mr-1" />
                注册于 {orderData.client.joinedAt}
              </div>
            </div>

            {/* Order Info */}
            <div className={`bg-white rounded-xl p-6 shadow-sm transition-all duration-500 delay-300 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}>
              <h3 className="font-semibold text-[#404145] mb-4">订单信息</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-[#74767e]">订单编号</span>
                  <span className="text-[#404145]">#{orderData.id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#74767e]">发布时间</span>
                  <span className="text-[#404145]">{orderData.postedAt}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#74767e]">截止日期</span>
                  <span className="text-[#404145]">{orderData.deadline}</span>
                </div>
              </div>
            </div>

            {/* Report */}
            <button className="flex items-center gap-2 text-[#74767e] hover:text-red-500 transition-colors text-sm">
              <Flag className="w-4 h-4" />
              举报此订单
            </button>
          </div>
        </div>
      </div>

      {/* Bid Dialog */}
      <Dialog open={showBidDialog} onOpenChange={setShowBidDialog}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>提交投标</DialogTitle>
            <DialogDescription>
              请填写您的报价和方案说明
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-[#404145] mb-2">报价金额</label>
                <input
                  type="number"
                  placeholder="输入金额"
                  value={bidPrice}
                  onChange={(e) => setBidPrice(e.target.value)}
                  className="w-full p-3 border border-[#e4e5e7] rounded-lg focus:outline-none focus:border-[#1dbf73]"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[#404145] mb-2">交付周期</label>
                <input
                  type="text"
                  placeholder="如：3天"
                  value={bidDuration}
                  onChange={(e) => setBidDuration(e.target.value)}
                  className="w-full p-3 border border-[#e4e5e7] rounded-lg focus:outline-none focus:border-[#1dbf73]"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-[#404145] mb-2">方案说明</label>
              <textarea
                placeholder="介绍您的方案和相关经验..."
                value={bidMessage}
                onChange={(e) => setBidMessage(e.target.value)}
                rows={4}
                className="w-full p-3 border border-[#e4e5e7] rounded-lg focus:outline-none focus:border-[#1dbf73] resize-none"
              />
            </div>
          </div>
          <div className="flex gap-3">
            <Button variant="outline" onClick={() => setShowBidDialog(false)} className="flex-1">
              取消
            </Button>
            <Button onClick={handleSubmitBid} className="flex-1 bg-[#1dbf73] hover:bg-[#19a463] text-white">
              确认投标
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
