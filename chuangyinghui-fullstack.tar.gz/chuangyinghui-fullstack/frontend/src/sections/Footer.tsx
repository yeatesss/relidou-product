import { Mail, Phone, MapPin } from 'lucide-react'

const footerLinks = {
  about: {
    title: '关于我们',
    links: [
      { name: '公司介绍', href: '#' },
      { name: '加入我们', href: '#' },
      { name: '联系我们', href: '#' },
      { name: '新闻动态', href: '#' },
    ],
  },
  help: {
    title: '帮助中心',
    links: [
      { name: '如何发布订单', href: '#' },
      { name: '创作者指南', href: '#' },
      { name: '常见问题', href: '#' },
      { name: '安全保障', href: '#' },
    ],
  },
  legal: {
    title: '服务条款',
    links: [
      { name: '用户协议', href: '#' },
      { name: '隐私政策', href: '#' },
      { name: '版权声明', href: '#' },
      { name: '违规处理', href: '#' },
    ],
  },
  social: {
    title: '关注我们',
    links: [
      { name: '微信公众号', href: '#' },
      { name: '微博', href: '#' },
      { name: '抖音', href: '#' },
      { name: '小红书', href: '#' },
    ],
  },
}

export default function Footer() {
  return (
    <footer className="bg-[#404145] text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
          {/* Brand */}
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-[#1dbf73] rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-lg">创</span>
              </div>
              <span className="text-xl font-bold">创影汇</span>
            </div>
            <p className="text-white/60 text-sm mb-4">
              专业的视频广告定制平台，连接品牌与创作者
            </p>
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-white/60 text-sm">
                <Mail className="w-4 h-4" />
                <span>contact@chuangyinghui.com</span>
              </div>
              <div className="flex items-center gap-2 text-white/60 text-sm">
                <Phone className="w-4 h-4" />
                <span>400-888-8888</span>
              </div>
              <div className="flex items-center gap-2 text-white/60 text-sm">
                <MapPin className="w-4 h-4" />
                <span>北京市朝阳区</span>
              </div>
            </div>
          </div>

          {/* Links */}
          {Object.values(footerLinks).map((section) => (
            <div key={section.title}>
              <h3 className="font-semibold mb-4">{section.title}</h3>
              <ul className="space-y-2">
                {section.links.map((link) => (
                  <li key={link.name}>
                    <a
                      href={link.href}
                      className="text-white/60 hover:text-[#1dbf73] transition-colors text-sm"
                    >
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom */}
        <div className="mt-12 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-white/40 text-sm">
            © 2026 创影汇. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <select className="bg-white/10 text-white/60 text-sm rounded px-3 py-1.5 border border-white/20">
              <option value="zh">简体中文</option>
              <option value="en">English</option>
            </select>
            <select className="bg-white/10 text-white/60 text-sm rounded px-3 py-1.5 border border-white/20">
              <option value="cny">CNY ¥</option>
              <option value="usd">USD $</option>
            </select>
          </div>
        </div>
      </div>
    </footer>
  )
}
