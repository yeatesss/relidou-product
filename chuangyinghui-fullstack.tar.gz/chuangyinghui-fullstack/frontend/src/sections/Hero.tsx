import { useEffect, useState, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { ArrowRight, Users, CheckCircle, TrendingUp } from 'lucide-react'

export default function Hero() {
  const [isVisible, setIsVisible] = useState(false)
  const [counts, setCounts] = useState({ creators: 0, orders: 0, satisfaction: 0 })
  const heroRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    setIsVisible(true)
    
    // Animate counters
    const duration = 1500
    const steps = 60
    const interval = duration / steps
    
    let step = 0
    const timer = setInterval(() => {
      step++
      const progress = step / steps
      const easeOut = 1 - Math.pow(1 - progress, 3)
      
      setCounts({
        creators: Math.floor(10000 * easeOut),
        orders: Math.floor(50000 * easeOut),
        satisfaction: Math.floor(98 * easeOut),
      })
      
      if (step >= steps) clearInterval(timer)
    }, interval)
    
    return () => clearInterval(timer)
  }, [])

  return (
    <section
      ref={heroRef}
      className="relative min-h-screen flex items-center pt-20 overflow-hidden"
    >
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="/images/hero-bg.jpg"
          alt="Video creator workspace"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#003912]/95 via-[#003912]/85 to-[#0a4226]/70" />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="max-w-3xl">
          {/* Main Headline */}
          <h1
            className={`text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6 transition-all duration-700 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            让优秀的创作者
            <br />
            <span className="text-[#1dbf73]">主动找到您</span>的视频需求
          </h1>

          {/* Subheadline */}
          <p
            className={`text-lg sm:text-xl text-white/80 mb-8 max-w-2xl transition-all duration-700 delay-100 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            发布您的广告视频订单，海量专业创作者竞标接单。
            <br className="hidden sm:block" />
            从创意到成品，全程无忧。
          </p>

          {/* CTA Buttons */}
          <div
            className={`flex flex-col sm:flex-row gap-4 mb-12 transition-all duration-700 delay-200 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            <Button
              size="lg"
              className="bg-[#1dbf73] hover:bg-[#19a463] text-white px-8 py-6 text-lg font-semibold rounded-md group"
            >
              免费发布订单
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white/30 text-white hover:bg-white/10 px-8 py-6 text-lg font-semibold rounded-md"
            >
              浏览创作者
            </Button>
          </div>

          {/* Stats */}
          <div
            className={`flex flex-wrap gap-8 sm:gap-12 transition-all duration-700 delay-300 ${
              isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
            }`}
          >
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center">
                <Users className="w-6 h-6 text-[#1dbf73]" />
              </div>
              <div>
                <div className="text-2xl sm:text-3xl font-bold text-white">
                  {counts.creators.toLocaleString()}+
                </div>
                <div className="text-sm text-white/60">专业创作者</div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center">
                <CheckCircle className="w-6 h-6 text-[#1dbf73]" />
              </div>
              <div>
                <div className="text-2xl sm:text-3xl font-bold text-white">
                  {counts.orders.toLocaleString()}+
                </div>
                <div className="text-sm text-white/60">完成订单</div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/10 rounded-full flex items-center justify-center">
                <TrendingUp className="w-6 h-6 text-[#1dbf73]" />
              </div>
              <div>
                <div className="text-2xl sm:text-3xl font-bold text-white">
                  {counts.satisfaction}%
                </div>
                <div className="text-sm text-white/60">满意度</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center pt-2">
          <div className="w-1.5 h-3 bg-white/50 rounded-full" />
        </div>
      </div>
    </section>
  )
}
